#!/system/bin/sh
pm trim-caches 999G
echo Cache de todos os apps foi limpo
