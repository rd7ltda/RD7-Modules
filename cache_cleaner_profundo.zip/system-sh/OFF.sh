#!/system/bin/sh
echo Esta acao nao e reversivel
