# By RD7VOID
pm enable --user 0 com.miui.msa.global 2>/dev/null
pm enable --user 0 com.miui.systemAdSolution 2>/dev/null
pm enable --user 0 com.miui.analytics 2>/dev/null
pm enable --user 0 com.xiaomi.mipicks 2>/dev/null
pm enable --user 0 com.mi.global.shop 2>/dev/null

pm enable --user 0 com.mfashiongallery.emag 2>/dev/null

pm enable --user 0 com.miui.miservice 2>/dev/null
pm enable --user 0 com.miui.bugreport 2>/dev/null
pm enable --user 0 com.miui.micloudsync 2>/dev/null
pm enable --user 0 com.miui.cloudbackup 2>/dev/null

pm enable --user 0 com.miui.hybrid 2>/dev/null
pm enable --user 0 com.miui.daemon 2>/dev/null

pm enable --user 0 com.facebook.appmanager 2>/dev/null
pm enable --user 0 com.facebook.services 2>/dev/null
pm enable --user 0 com.facebook.system 2>/dev/null

settings delete global window_animation_scale
settings delete global transition_animation_scale
settings delete global animator_duration_scale
settings delete global development_settings_enabled

cmd notification post -S bigtext -t "🚀 Xiaomi Debloat OFF | Created By @RD7VOID"
