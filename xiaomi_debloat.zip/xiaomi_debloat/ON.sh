# By RD7VOID — RD7 Tools: Xiaomi Debloat & Buffer
# MIUI / HyperOS - use disable-user (reversivel)

# ---- Ads e telemetria do sistema ----
pm disable-user --user 0 com.miui.msa.global 2>/dev/null
pm disable-user --user 0 com.miui.systemAdSolution 2>/dev/null
pm disable-user --user 0 com.miui.analytics 2>/dev/null
pm disable-user --user 0 com.xiaomi.mipicks 2>/dev/null
pm disable-user --user 0 com.mi.global.shop 2>/dev/null

# ---- Wallpaper Carousel (anuncios na lockscreen) ----
pm disable-user --user 0 com.mfashiongallery.emag 2>/dev/null

# ---- Suporte / Bug report / Mi Cloud ----
pm disable-user --user 0 com.miui.miservice 2>/dev/null
pm disable-user --user 0 com.miui.bugreport 2>/dev/null
pm disable-user --user 0 com.miui.micloudsync 2>/dev/null
pm disable-user --user 0 com.miui.cloudbackup 2>/dev/null

# ---- Servicos hibridos / cartoes de terceiros no launcher ----
pm disable-user --user 0 com.miui.hybrid 2>/dev/null
pm disable-user --user 0 com.miui.daemon 2>/dev/null

# ---- Facebook pre-instalado (comum em versao Global) ----
pm disable-user --user 0 com.facebook.appmanager 2>/dev/null
pm disable-user --user 0 com.facebook.services 2>/dev/null
pm disable-user --user 0 com.facebook.system 2>/dev/null

# ---- Buffer de performance ----
settings put global window_animation_scale 0
settings put global transition_animation_scale 0
settings put global animator_duration_scale 0
settings put global development_settings_enabled 1
pm trim-caches 512M 2>/dev/null

cmd notification post -S bigtext -t "🚀 Xiaomi Debloat ON | Created By @RD7VOID"
