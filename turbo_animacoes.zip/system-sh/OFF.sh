#!/system/bin/sh
settings put global window_animation_scale 1
settings put global transition_animation_scale 1
settings put global animator_duration_scale 1
echo Animacoes restauradas para 1x padrao
