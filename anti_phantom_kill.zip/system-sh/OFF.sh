#!/system/bin/sh
settings put global settings_enable_monitor_phantom_procs true
echo Monitor de phantom processes reativado
