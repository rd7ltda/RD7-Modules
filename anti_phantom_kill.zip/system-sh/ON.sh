#!/system/bin/sh
settings put global settings_enable_monitor_phantom_procs false
echo Monitor de phantom processes desativado
