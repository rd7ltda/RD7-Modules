# By RD7VOID — RD7 Tools: Resfriar Celular
# Reduz carga de CPU/GPU/tela pra baixar temperatura real (nao e so cosmetico)

# ---- Trava a taxa de atualizacao em 60Hz (tela e uma das maiores fontes de calor) ----
settings put system peak_refresh_rate 60.0
settings put system min_refresh_rate 60.0

# ---- Avisa o sistema termico pra entrar em modo de economia (throttling leve) ----
# severidade 2 = MODERATE (reduz clocks sem travar o aparelho)
cmd thermalservice override-status 2 2>/dev/null

# ---- Mata apps de terceiros rodando em segundo plano ----
for pkg in $(pm list packages -3 | sed 's/package://'); do
  am force-stop "$pkg" 2>/dev/null
done

# ---- Zera animacoes (menos trabalho pra GPU) ----
settings put global window_animation_scale 0
settings put global transition_animation_scale 0
settings put global animator_duration_scale 0

# ---- Limpa cache acumulado ----
pm trim-caches 512M 2>/dev/null

cmd notification post -S bigtext -t "❄️ Resfriar Celular ON | Created By @RD7VOID"
