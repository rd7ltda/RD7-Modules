# By RD7VOID
settings delete system peak_refresh_rate
settings delete system min_refresh_rate

cmd thermalservice override-status 0 2>/dev/null

settings delete global window_animation_scale
settings delete global transition_animation_scale
settings delete global animator_duration_scale

cmd notification post -S bigtext -t "❄️ Resfriar Celular OFF | Created By @RD7VOID"
