# By RD7VOID — RD7 Tools: Samsung Debloat & Buffer
# Testado como base: Galaxy M54 5G (One UI 8.5)
# Usa disable-user (reversivel) em vez de uninstall

# ---- Bixby ----
pm disable-user --user 0 com.samsung.android.bixby.agent 2>/dev/null
pm disable-user --user 0 com.samsung.android.bixby.service 2>/dev/null
pm disable-user --user 0 com.samsung.android.bixbyvision.framework 2>/dev/null
pm disable-user --user 0 com.samsung.android.visionintelligence 2>/dev/null
pm disable-user --user 0 com.samsung.android.rubin.app 2>/dev/null

# ---- Facebook pre-instalado ----
pm disable-user --user 0 com.facebook.appmanager 2>/dev/null
pm disable-user --user 0 com.facebook.services 2>/dev/null
pm disable-user --user 0 com.facebook.system 2>/dev/null
pm disable-user --user 0 com.facebook.katana 2>/dev/null

# ---- Microsoft Link to Windows ----
pm disable-user --user 0 com.microsoft.appmanager 2>/dev/null

# ---- Samsung Free / Daily Board / conteudo ----
pm disable-user --user 0 com.samsung.android.app.spage 2>/dev/null
pm disable-user --user 0 com.samsung.android.aremoji 2>/dev/null
pm disable-user --user 0 com.samsung.android.arzone 2>/dev/null

# ---- Samsung Kids ----
pm disable-user --user 0 com.samsung.android.kidsinstaller 2>/dev/null

# ---- Loja de temas e afins ----
pm disable-user --user 0 com.samsung.android.themestore 2>/dev/null
pm disable-user --user 0 com.samsung.android.app.dressroom 2>/dev/null

# ---- Samsung Pay / Wallet (comente se voce usa) ----
pm disable-user --user 0 com.samsung.android.spay 2>/dev/null
pm disable-user --user 0 com.samsung.android.spaylite 2>/dev/null

# ---- Outros servicos de segundo plano ----
pm disable-user --user 0 com.samsung.android.beaconmanager 2>/dev/null
pm disable-user --user 0 com.samsung.android.mateagent 2>/dev/null
pm disable-user --user 0 com.samsung.android.dqagent 2>/dev/null
pm disable-user --user 0 com.samsung.android.game.gametools 2>/dev/null

# ---- Buffer de performance (One UI mais leve) ----
settings put global window_animation_scale 0
settings put global transition_animation_scale 0
settings put global animator_duration_scale 0
settings put global development_settings_enabled 1
pm trim-caches 512M 2>/dev/null

cmd notification post -S bigtext -t "🚀 Samsung Debloat ON | Created By @RD7VOID"
