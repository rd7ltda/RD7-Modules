# By RD7VOID
pm enable --user 0 com.samsung.android.bixby.agent 2>/dev/null
pm enable --user 0 com.samsung.android.bixby.service 2>/dev/null
pm enable --user 0 com.samsung.android.bixbyvision.framework 2>/dev/null
pm enable --user 0 com.samsung.android.visionintelligence 2>/dev/null
pm enable --user 0 com.samsung.android.rubin.app 2>/dev/null

pm enable --user 0 com.facebook.appmanager 2>/dev/null
pm enable --user 0 com.facebook.services 2>/dev/null
pm enable --user 0 com.facebook.system 2>/dev/null
pm enable --user 0 com.facebook.katana 2>/dev/null

pm enable --user 0 com.microsoft.appmanager 2>/dev/null

pm enable --user 0 com.samsung.android.app.spage 2>/dev/null
pm enable --user 0 com.samsung.android.aremoji 2>/dev/null
pm enable --user 0 com.samsung.android.arzone 2>/dev/null

pm enable --user 0 com.samsung.android.kidsinstaller 2>/dev/null

pm enable --user 0 com.samsung.android.themestore 2>/dev/null
pm enable --user 0 com.samsung.android.app.dressroom 2>/dev/null

pm enable --user 0 com.samsung.android.spay 2>/dev/null
pm enable --user 0 com.samsung.android.spaylite 2>/dev/null

pm enable --user 0 com.samsung.android.beaconmanager 2>/dev/null
pm enable --user 0 com.samsung.android.mateagent 2>/dev/null
pm enable --user 0 com.samsung.android.dqagent 2>/dev/null
pm enable --user 0 com.samsung.android.game.gametools 2>/dev/null

settings delete global window_animation_scale
settings delete global transition_animation_scale
settings delete global animator_duration_scale
settings delete global development_settings_enabled

cmd notification post -S bigtext -t "🚀 Samsung Debloat OFF | Created By @RD7VOID"
