# By RD7VOID — RD7 Tools: Realme/Oppo Debloat & Buffer
# ColorOS / Realme UI - nomes de pacote variam bastante, use disable-user (reversivel)

# ---- Navegador e apps duplicados ----
pm disable-user --user 0 com.heytap.browser 2>/dev/null
pm disable-user --user 0 com.oppo.browser 2>/dev/null
pm disable-user --user 0 com.heytap.music 2>/dev/null
pm disable-user --user 0 com.oppo.quicksearchbox 2>/dev/null

# ---- Wallpapers ----
pm disable-user --user 0 com.coloros.solarwallpaper 2>/dev/null
pm disable-user --user 0 com.coloros.wallpapers 2>/dev/null

# ---- Weather / Assistente de tela negativa ----
pm disable-user --user 0 com.coloros.weather.service 2>/dev/null
pm disable-user --user 0 com.coloros.assistantscreen 2>/dev/null

# ---- Facebook pre-instalado ----
pm disable-user --user 0 com.facebook.appmanager 2>/dev/null
pm disable-user --user 0 com.facebook.services 2>/dev/null
pm disable-user --user 0 com.facebook.system 2>/dev/null

# ---- Buffer de performance ----
settings put global window_animation_scale 0
settings put global transition_animation_scale 0
settings put global animator_duration_scale 0
settings put global development_settings_enabled 1
pm trim-caches 512M 2>/dev/null

cmd notification post -S bigtext -t "🚀 Realme/Oppo Debloat ON | Created By @RD7VOID"
