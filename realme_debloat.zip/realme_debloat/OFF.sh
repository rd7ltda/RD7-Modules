# By RD7VOID
pm enable --user 0 com.heytap.browser 2>/dev/null
pm enable --user 0 com.oppo.browser 2>/dev/null
pm enable --user 0 com.heytap.music 2>/dev/null
pm enable --user 0 com.oppo.quicksearchbox 2>/dev/null

pm enable --user 0 com.coloros.solarwallpaper 2>/dev/null
pm enable --user 0 com.coloros.wallpapers 2>/dev/null

pm enable --user 0 com.coloros.weather.service 2>/dev/null
pm enable --user 0 com.coloros.assistantscreen 2>/dev/null

pm enable --user 0 com.facebook.appmanager 2>/dev/null
pm enable --user 0 com.facebook.services 2>/dev/null
pm enable --user 0 com.facebook.system 2>/dev/null

settings delete global window_animation_scale
settings delete global transition_animation_scale
settings delete global animator_duration_scale
settings delete global development_settings_enabled

cmd notification post -S bigtext -t "🚀 Realme/Oppo Debloat OFF | Created By @RD7VOID"
