# By RD7VOID — RD7 Tools: Renderizacao Vulkan
# Troca o backend do HWUI (UI do sistema) pra Skia/Vulkan
# Nao sobrevive a reboot sem persist prop (resetprop --persist, se disponivel)

resetprop --persist debug.hwui.renderer skiavk 2>/dev/null || setprop debug.hwui.renderer skiavk

cmd notification post -S bigtext -t "🌋 Renderizacao Vulkan ON | Created By @RD7VOID"
