# By RD7VOID
# Volta pro backend padrao do sistema (Skia/OpenGL)
resetprop --persist debug.hwui.renderer skiagl 2>/dev/null || setprop debug.hwui.renderer skiagl

cmd notification post -S bigtext -t "🌋 Renderizacao Vulkan OFF | Created By @RD7VOID"
