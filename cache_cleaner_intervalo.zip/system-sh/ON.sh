#!/system/bin/sh
setprop persist.rd7.cache_interval_min 30
INTERVAL_MIN=$(getprop persist.rd7.cache_interval_min)
SEC=$((INTERVAL_MIN * 60))
LOOP=/data/local/tmp/rd7_cache_loop.sh
cat > "$LOOP" << SCRIPT
#!/system/bin/sh
while true; do
  pm trim-caches 999G
  sleep $SEC
done
SCRIPT
chmod 755 "$LOOP"
nohup sh "$LOOP" > /dev/null 2>&1 &
echo Faxina de cache agendada a cada $INTERVAL_MIN minutos
