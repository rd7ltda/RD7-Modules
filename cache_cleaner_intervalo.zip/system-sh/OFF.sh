#!/system/bin/sh
pkill -f rd7_cache_loop.sh
rm -f /data/local/tmp/rd7_cache_loop.sh
echo Faxina periodica de cache desativada
