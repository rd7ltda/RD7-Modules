# By RD7VOID — RD7 Tools: Motorola Debloat & Buffer
# Near-stock Android - lista menor de bloat, use disable-user (reversivel)

# ---- Apps Motorola de suporte/demo ----
pm disable-user --user 0 com.motorola.help 2>/dev/null
pm disable-user --user 0 com.motorola.demo 2>/dev/null
pm disable-user --user 0 com.motorola.entitlement 2>/dev/null
pm disable-user --user 0 com.motorola.dm 2>/dev/null

# ---- Facebook pre-instalado ----
pm disable-user --user 0 com.facebook.appmanager 2>/dev/null
pm disable-user --user 0 com.facebook.services 2>/dev/null
pm disable-user --user 0 com.facebook.system 2>/dev/null

# ---- Antivirus de terceiros pre-instalado (varia por modelo) ----
pm disable-user --user 0 com.mcafee.wsandroid 2>/dev/null
pm disable-user --user 0 com.wsomacp 2>/dev/null

# ---- Buffer de performance ----
settings put global window_animation_scale 0
settings put global transition_animation_scale 0
settings put global animator_duration_scale 0
settings put global development_settings_enabled 1
pm trim-caches 512M 2>/dev/null

cmd notification post -S bigtext -t "🚀 Motorola Debloat ON | Created By @RD7VOID"
