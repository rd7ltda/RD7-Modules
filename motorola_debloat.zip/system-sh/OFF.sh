# By RD7VOID
pm enable --user 0 com.motorola.help 2>/dev/null
pm enable --user 0 com.motorola.demo 2>/dev/null
pm enable --user 0 com.motorola.entitlement 2>/dev/null
pm enable --user 0 com.motorola.dm 2>/dev/null

pm enable --user 0 com.facebook.appmanager 2>/dev/null
pm enable --user 0 com.facebook.services 2>/dev/null
pm enable --user 0 com.facebook.system 2>/dev/null

pm enable --user 0 com.mcafee.wsandroid 2>/dev/null
pm enable --user 0 com.wsomacp 2>/dev/null

settings delete global window_animation_scale
settings delete global transition_animation_scale
settings delete global animator_duration_scale
settings delete global development_settings_enabled

cmd notification post -S bigtext -t "🚀 Motorola Debloat OFF | Created By @RD7VOID"
