#!/system/bin/sh
echo Esta acao nao tem desfazer - os apps abrem normalmente ao serem tocados de novo
