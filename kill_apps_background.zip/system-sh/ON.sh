#!/system/bin/sh
for PKG in $(pm list packages -3 | sed s/package://); do
  if [ "$PKG" != "com.rd7.rd7_tools" ]; then
    am force-stop "$PKG"
  fi
done
echo Apps de terceiros em segundo plano foram encerrados
