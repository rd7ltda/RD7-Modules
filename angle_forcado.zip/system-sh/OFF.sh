# By RD7VOID
settings put global angle_gl_driver_all_angle 0

cmd notification post -S bigtext -t "🔺 ANGLE Forcado OFF | Created By @RD7VOID"
