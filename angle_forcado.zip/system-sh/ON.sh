# By RD7VOID — RD7 Tools: ANGLE Forcado
# Forca todos os apps/jogos que usam OpenGL ES a rodar via ANGLE (traducao pra Vulkan)
# Settings.Global de verdade - sobrevive a reboot

settings put global angle_gl_driver_all_angle 1

cmd notification post -S bigtext -t "🔺 ANGLE Forcado ON | Created By @RD7VOID"
