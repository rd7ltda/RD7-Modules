#!/system/bin/sh
cmd package compile -m speed -a
echo Recompilacao ART em modo speed concluida
