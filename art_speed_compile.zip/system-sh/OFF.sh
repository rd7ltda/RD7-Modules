#!/system/bin/sh
cmd package compile -m speed-profile -a
echo Apps revertidos para compilacao padrao
