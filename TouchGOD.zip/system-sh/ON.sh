# By RD7VOID — RD7 Tools: Touch GOD
settings put system touch.pressure.scale 0.001
settings put system windowsmgr.max_events_per_sec 150
settings put system persist.sys.scrolling_cache 0
settings put system touch.size.calibration diameter
settings put system view.touch_slop 2
settings put global debug.performance.tuning 1
settings put global video.accelerate.hw 1
settings put global persist.sys.ui.hw true
settings put global ro.max.fling_velocity 14000
settings put global ro.min.fling_velocity 8000
settings put global window_animation_scale 0
settings put global transition_animation_scale 0
settings put global animator_duration_scale 0

cmd notification post -S bigtext -t "🚀 Touch GOD | Created By @RD7VOID"