# By RD7VOID
settings delete system touch.pressure.scale
settings delete system windowsmgr.max_events_per_sec
settings delete system persist.sys.scrolling_cache
settings delete system touch.size.calibration
settings delete system view.touch_slop
settings delete global debug.performance.tuning
settings delete global video.accelerate.hw
settings delete global persist.sys.ui.hw
settings delete global ro.max.fling_velocity
settings delete global ro.min.fling_velocity
settings delete global window_animation_scale
settings delete global transition_animation_scale
settings delete global animator_duration_scale

cmd notification post -S bigtext -t "🚀 DESATIVADO Touch GOD | Created By @RD7VOID"