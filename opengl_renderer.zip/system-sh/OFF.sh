# By RD7VOID
# Remove o override e deixa o sistema decidir sozinho (comportamento de fabrica)
resetprop --delete debug.hwui.renderer 2>/dev/null || setprop debug.hwui.renderer ""

cmd notification post -S bigtext -t "🖼️ Renderizacao OpenGL OFF | Created By @RD7VOID"
