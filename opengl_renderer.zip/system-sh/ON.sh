# By RD7VOID — RD7 Tools: Renderizacao OpenGL (padrao)
resetprop --persist debug.hwui.renderer skiagl 2>/dev/null || setprop debug.hwui.renderer skiagl

cmd notification post -S bigtext -t "🖼️ Renderizacao OpenGL ON | Created By @RD7VOID"
