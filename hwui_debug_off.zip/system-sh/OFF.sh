#!/system/bin/sh
setprop debug.hwui.profile visual_bars
echo Overlay visual de profile de GPU reativado
