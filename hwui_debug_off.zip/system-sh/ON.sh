#!/system/bin/sh
setprop debug.hwui.profile false
setprop debug.hwui.overdraw false
echo Overlays de debug de GPU desativados
